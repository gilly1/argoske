
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

/*!40000 ALTER TABLE `approve_statuses` DISABLE KEYS */;
INSERT INTO `approve_statuses` (`id`, `approver_id`, `user_id`, `weight`, `reason`, `super_reason`, `model`, `model_id`, `status`, `approved`, `approved_by`, `super_approver`, `is_super_approved`, `deleted_at`, `created_at`, `updated_at`) VALUES (29,1,2,1,NULL,NULL,'App\\Model\\Sage\\Doduments',1,'0','0',NULL,'0','0',NULL,'2020-12-08 05:51:28','2020-12-08 05:51:28'),(30,2,3,2,NULL,NULL,'App\\Model\\Sage\\Doduments',1,'0','0',NULL,'0','0',NULL,'2020-12-08 05:51:28','2020-12-08 05:51:28');
/*!40000 ALTER TABLE `approve_statuses` ENABLE KEYS */;

/*!40000 ALTER TABLE `approvers` DISABLE KEYS */;
INSERT INTO `approvers` (`id`, `user_id`, `weight`, `workflow_id`, `super_approver`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,2,1,1,'0',NULL,'2020-12-07 03:54:04','2020-12-07 03:54:04'),(2,3,2,1,'0',NULL,'2020-12-07 03:54:17','2020-12-07 03:54:17'),(3,4,0,1,'1',NULL,'2020-12-07 03:54:32','2020-12-07 03:54:32');
/*!40000 ALTER TABLE `approvers` ENABLE KEYS */;

/*!40000 ALTER TABLE `doduments` DISABLE KEYS */;
INSERT INTO `doduments` (`id`, `doc_type`, `doc_number`, `date`, `contact_id`, `contact_code`, `contact_name`, `contact_address`, `contact_email`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'Pdf','10001','2020-12-07',12,10100,'John Doe','Mlolongo','john@john.com','WP',NULL,'2020-12-07 03:41:36','2020-12-08 05:51:28');
/*!40000 ALTER TABLE `doduments` ENABLE KEYS */;

/*!40000 ALTER TABLE `doduments_details` DISABLE KEYS */;
INSERT INTO `doduments_details` (`id`, `doc_id`, `item_id`, `item_code`, `item_name`, `unit_id`, `unit`, `unit_price_ex`, `unit_price_inc`, `quantity`, `discount`, `tax_id`, `tax_percentage`, `tax_amount`, `discount_amount`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,1,1,'1010','First Item',1,1,10,12,10,10,16,16,1000,1000,NULL,'2020-12-07 03:42:47','2020-12-07 03:42:47');
/*!40000 ALTER TABLE `doduments_details` ENABLE KEYS */;

/*!40000 ALTER TABLE `email_templates` DISABLE KEYS */;
INSERT INTO `email_templates` (`id`, `name`, `from`, `email_name`, `cc`, `subject`, `body`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'Noel Chavez','koli@mailinator.com','famopok@mailinator.com','sucyqysi@mailinator.com','boqarezet@mailinator.com','Velit exercitation s',NULL,'2020-12-07 03:44:47','2020-12-07 03:44:47'),(2,'Alana Reeves','licora@mailinator.com','wiqece@mailinator.com','vydozususo@mailinator.com','nocinojo@mailinator.com','Fugit dolorem provi',NULL,'2020-12-07 03:44:57','2020-12-07 03:44:57'),(3,'Karleigh Moss','gowe@mailinator.com','hiluviloly@mailinator.com','nohuhyr@mailinator.com','genim@mailinator.com','Excepturi dolore omn',NULL,'2020-12-07 03:45:48','2020-12-07 03:45:48');
/*!40000 ALTER TABLE `email_templates` ENABLE KEYS */;

/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;

/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` (`id`, `type`, `text`, `user_id`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'critical','Organization Details  - Velazquez and Booker Inc - Added by developer',1,NULL,'2020-12-07 02:56:35','2020-12-07 02:56:35'),(2,'critical','Documents  -  - Added by developer',1,NULL,'2020-12-07 03:41:36','2020-12-07 03:41:36'),(3,'critical','Documents  -  - Added by developer',1,NULL,'2020-12-07 03:42:47','2020-12-07 03:42:47'),(4,'critical','Role  - Approvers - Added by developer',1,NULL,'2020-12-07 03:43:54','2020-12-07 03:43:54'),(5,'critical','User  - User - Added by developer',1,NULL,'2020-12-07 03:44:29','2020-12-07 03:44:29'),(6,'critical','Email Template  - Noel Chavez - Added by developer',1,NULL,'2020-12-07 03:44:47','2020-12-07 03:44:47'),(7,'critical','Email Template  - Alana Reeves - Added by developer',1,NULL,'2020-12-07 03:44:58','2020-12-07 03:44:58'),(8,'critical','Email Template  - Karleigh Moss - Added by developer',1,NULL,'2020-12-07 03:45:48','2020-12-07 03:45:48'),(9,'critical','Email Template Assignment -  - Added by developer',1,NULL,'2020-12-07 03:48:25','2020-12-07 03:48:25'),(10,'critical','Email Template Assignment -  - Updated by developer',1,NULL,'2020-12-07 03:48:40','2020-12-07 03:48:40'),(11,'critical','User  - User2 - Added by developer',1,NULL,'2020-12-07 03:49:32','2020-12-07 03:49:32'),(12,'critical','Role - Approvers - Updated by developer',1,NULL,'2020-12-07 03:51:10','2020-12-07 03:51:10'),(13,'critical','Workflow  - Workflow1 - Added by developer',1,NULL,'2020-12-07 03:52:42','2020-12-07 03:52:42'),(14,'critical','Workflow Limit  -  - Added by developer',1,NULL,'2020-12-07 03:53:02','2020-12-07 03:53:02'),(15,'critical','User  - Super Approver - Added by developer',1,NULL,'2020-12-07 03:53:47','2020-12-07 03:53:47'),(16,'critical','Approver  - User for Workflow1 - Added by developer',1,NULL,'2020-12-07 03:54:04','2020-12-07 03:54:04'),(17,'critical','Approver  - User2 for Workflow1 - Added by developer',1,NULL,'2020-12-07 03:54:17','2020-12-07 03:54:17'),(18,'critical','Approver  - Super Approver for Workflow1 - Added by developer',1,NULL,'2020-12-07 03:54:32','2020-12-07 03:54:32'),(19,'critical','User - Super Approver - Updated by developer',1,NULL,'2020-12-07 16:29:17','2020-12-07 16:29:17'),(20,'critical','User - Super Approver - Updated by developer',1,NULL,'2020-12-07 16:34:26','2020-12-07 16:34:26'),(21,'critical','User - Super Approver - Updated by developer',1,NULL,'2020-12-07 16:39:35','2020-12-07 16:39:35'),(22,'critical','User - Super Approver - Updated by developer',1,NULL,'2020-12-07 16:40:01','2020-12-07 16:40:01'),(23,'critical','User - Super Approver - Updated by developer',1,NULL,'2020-12-07 16:40:49','2020-12-07 16:40:49'),(24,'critical','User - Super Approver - Updated by developer',1,NULL,'2020-12-07 16:41:47','2020-12-07 16:41:47'),(25,'critical','User - Super Approver - Updated by developer',1,NULL,'2020-12-07 16:44:16','2020-12-07 16:44:16'),(26,'critical','User - User - Updated by developer',1,NULL,'2020-12-07 16:44:49','2020-12-07 16:44:49'),(27,'critical','User - User2 - Updated by developer',1,NULL,'2020-12-07 16:45:03','2020-12-07 16:45:03'),(28,'critical','User - Super Approver - Updated by developer',1,NULL,'2020-12-07 16:45:21','2020-12-07 16:45:21'),(29,'critical','Role - Approvers - Updated by developer',1,NULL,'2020-12-07 16:56:55','2020-12-07 16:56:55'),(30,'critical','Role - Approvers - Updated by developer',1,NULL,'2020-12-07 16:58:01','2020-12-07 16:58:01'),(31,'critical','Role - Approvers - Updated by developer',1,NULL,'2020-12-07 16:59:49','2020-12-07 16:59:49'),(32,'critical','Role - Approvers - Updated by developer',1,NULL,'2020-12-07 17:00:52','2020-12-07 17:00:52'),(33,'critical','Role - Approvers - Updated by developer',1,NULL,'2020-12-07 17:01:24','2020-12-07 17:01:24');
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;

/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2020_04_22_145838_create_tests_table',1),(5,'2020_04_24_140527_create_roles_table',1),(6,'2020_04_24_140916_create_role_user_table',1),(7,'2020_04_24_221402_create_notifications_table',1),(8,'2020_04_25_084514_create_logs_table',1),(9,'2020_11_27_141128_create_second_tests_table',1),(10,'2020_11_28_101436_create_money_table',1),(11,'2020_11_29_155853_create_permission_tables',1),(12,'2020_11_29_172354_create_modules_table',1),(13,'2020_12_02_164624_create_workflows_table',1),(14,'2020_12_02_164810_create_workflow_limits_table',1),(15,'2020_12_02_164847_create_approvers_table',1),(16,'2020_12_02_164929_create_approve_statuses_table',1),(17,'2020_12_03_070917_create_email_templates_table',1),(18,'2020_12_03_075909_create_organization_details_table',1),(19,'2020_12_03_084849_create_doduments_table',1),(20,'2020_12_03_084935_create_doduments_details_table',1),(21,'2020_12_04_113645_create_template_assignments_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;

/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES (1,'App\\User',1),(2,'App\\User',2),(2,'App\\User',3),(2,'App\\User',4);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;

/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;

/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;

/*!40000 ALTER TABLE `organization_details` DISABLE KEYS */;
INSERT INTO `organization_details` (`id`, `name`, `logo`, `country`, `city`, `branch`, `telephone_no`, `mobile`, `email`, `website`, `postal_address`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'Velazquez and Booker Inc','DAmAezjW0AE7GWL_1607320594.png','Totam laudantium do','Enim similique commo','Qui ratione aut dolo','+1 (168) 177-1249','Sint eligendi et mol','tiqipox@mailinator.com','https://www.vywefufyn.cc','Molestiae architecto',NULL,'2020-12-07 02:56:34','2020-12-07 02:56:34');
/*!40000 ALTER TABLE `organization_details` ENABLE KEYS */;

/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `module_id`, `permission_key`, `created_at`, `updated_at`) VALUES (1,'view_users','web',1,'system_users','2020-12-07 02:55:22','2020-12-07 02:55:22'),(2,'create_users','web',1,'system_users','2020-12-07 02:55:22','2020-12-07 02:55:22'),(3,'edit_users','web',1,'system_users','2020-12-07 02:55:22','2020-12-07 02:55:22'),(4,'delete_users','web',1,'system_users','2020-12-07 02:55:22','2020-12-07 02:55:22'),(5,'view_roles','web',1,'roles','2020-12-07 02:55:22','2020-12-07 02:55:22'),(6,'create_roles','web',1,'roles','2020-12-07 02:55:22','2020-12-07 02:55:22'),(7,'edit_roles','web',1,'roles','2020-12-07 02:55:22','2020-12-07 02:55:22'),(8,'delete_roles','web',1,'roles','2020-12-07 02:55:22','2020-12-07 02:55:22'),(9,'view_workflow','web',2,'workflow','2020-12-07 02:55:22','2020-12-07 02:55:22'),(10,'create_workflow','web',2,'workflow','2020-12-07 02:55:22','2020-12-07 02:55:22'),(11,'edit_workflow','web',2,'workflow','2020-12-07 02:55:22','2020-12-07 02:55:22'),(12,'delete_workflow','web',2,'workflow','2020-12-07 02:55:22','2020-12-07 02:55:22'),(13,'view_workflowLimit','web',2,'workflowLimit','2020-12-07 02:55:22','2020-12-07 02:55:22'),(14,'create_workflowLimit','web',2,'workflowLimit','2020-12-07 02:55:22','2020-12-07 02:55:22'),(15,'edit_workflowLimit','web',2,'workflowLimit','2020-12-07 02:55:22','2020-12-07 02:55:22'),(16,'delete_workflowLimit','web',2,'workflowLimit','2020-12-07 02:55:22','2020-12-07 02:55:22'),(17,'view_approvers','web',2,'approvers','2020-12-07 02:55:22','2020-12-07 02:55:22'),(18,'create_approvers','web',2,'approvers','2020-12-07 02:55:22','2020-12-07 02:55:22'),(19,'edit_approvers','web',2,'approvers','2020-12-07 02:55:22','2020-12-07 02:55:22'),(20,'delete_approvers','web',2,'approvers','2020-12-07 02:55:22','2020-12-07 02:55:22'),(21,'view_emailTemplate','web',3,'email_templates','2020-12-07 02:55:22','2020-12-07 02:55:22'),(22,'create_emailTemplate','web',3,'email_templates','2020-12-07 02:55:23','2020-12-07 02:55:23'),(23,'edit_emailTemplate','web',3,'email_templates','2020-12-07 02:55:23','2020-12-07 02:55:23'),(24,'delete_emailTemplate','web',3,'email_templates','2020-12-07 02:55:23','2020-12-07 02:55:23'),(25,'view_organizationDetails','web',4,'organization_details','2020-12-07 02:55:23','2020-12-07 02:55:23'),(26,'create_organizationDetails','web',4,'organization_details','2020-12-07 02:55:23','2020-12-07 02:55:23'),(27,'edit_organizationDetails','web',4,'organization_details','2020-12-07 02:55:23','2020-12-07 02:55:23'),(28,'delete_organizationDetails','web',4,'organization_details','2020-12-07 02:55:23','2020-12-07 02:55:23'),(29,'view_documentsdetails','web',5,'documents_details','2020-12-07 02:55:23','2020-12-07 02:55:23'),(30,'create_documentsdetails','web',5,'documents_details','2020-12-07 02:55:23','2020-12-07 02:55:23'),(31,'edit_documentsdetails','web',5,'documents_details','2020-12-07 02:55:23','2020-12-07 02:55:23'),(32,'delete_documentsdetails','web',5,'documents_details','2020-12-07 02:55:23','2020-12-07 02:55:23'),(33,'view_documents','web',5,'documents','2020-12-07 02:55:23','2020-12-07 02:55:23'),(34,'create_documents','web',5,'documents','2020-12-07 02:55:23','2020-12-07 02:55:23'),(35,'edit_documents','web',5,'documents','2020-12-07 02:55:23','2020-12-07 02:55:23'),(36,'delete_documents','web',5,'documents','2020-12-07 02:55:23','2020-12-07 02:55:23');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;

/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES (33,2);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;

/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `name`, `guard_name`, `deleteable`, `created_at`, `updated_at`) VALUES (1,'Super Admin','web',0,'2020-12-07 02:55:24','2020-12-07 02:55:24'),(2,'Approvers','web',1,'2020-12-07 03:43:53','2020-12-07 03:43:53');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;

/*!40000 ALTER TABLE `template_assignments` DISABLE KEYS */;
INSERT INTO `template_assignments` (`id`, `approval`, `rejection`, `client`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,1,3,2,NULL,'2020-12-07 03:48:24','2020-12-07 03:48:40');
/*!40000 ALTER TABLE `template_assignments` ENABLE KEYS */;

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `name`, `email`, `sign`, `email_verified_at`, `password`, `remember_token`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'developer','developer@developer.com','',NULL,'$2y$10$H8KcmuKc9yANoticCJAM.OpvIQmuPUmHX2mJSIZuNUwHylnlZDAki',NULL,NULL,'2020-12-07 02:55:24','2020-12-07 02:55:24'),(2,'User','user@user.com','dedex_1607370289.png',NULL,'$2y$10$QzdBEMcyJhI6TNVZRuQF8OFDqjuGY7FdiwEWvXoBgO1lK/um1LNqu',NULL,NULL,'2020-12-07 03:44:29','2020-12-07 16:44:49'),(3,'User2','users@user.com','Clipart Black Tent - 800x800_1607370303.png',NULL,'$2y$10$mQklfEsupATMVfRhI6UYxeTPezf3moEbhmNz852fegseezt7mHAO2',NULL,NULL,'2020-12-07 03:49:32','2020-12-07 16:45:03'),(4,'Super Approver','approver@approver.com','logoz_1607370321.png',NULL,'$2y$10$79jJGfZlgO5zj/2yZ63mBeX6wfnO0o0B8DLjmMtyQgBfoTYixUGm2',NULL,NULL,'2020-12-07 03:53:46','2020-12-07 16:45:21');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40000 ALTER TABLE `workflow_limits` DISABLE KEYS */;
INSERT INTO `workflow_limits` (`id`, `workflow_id`, `min_amount`, `max_amount`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,1,0,1000000000,NULL,'2020-12-07 03:53:01','2020-12-07 03:53:01');
/*!40000 ALTER TABLE `workflow_limits` ENABLE KEYS */;

/*!40000 ALTER TABLE `workflows` DISABLE KEYS */;
INSERT INTO `workflows` (`id`, `name`, `description`, `deleted_at`, `created_at`, `updated_at`) VALUES (1,'Workflow1','qwertyu',NULL,'2020-12-07 03:52:42','2020-12-07 03:52:42');
/*!40000 ALTER TABLE `workflows` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

